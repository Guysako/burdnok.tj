
function showLogin() {
    document.getElementById('auth').style.display = 'block';
}

function registerUser() {
    alert('Сабти ном анҷом ёфт!');
}

function loginUser() {
    alert('Шумо вуруд кардед!');
}

let points = 0;
function earnPoints(amount) {
    points += amount;
    document.getElementById('points').innerText = points;
}

function withdrawMoney() {
    alert('Пул бурда шуд!');
}

function processPayment() {
    alert('Пардохт иҷро шуд!');
}
